﻿#include <iostream>
#include <windows.h>
#include <fstream>
#include <string>
#include <conio.h>
#include "bank_account.h"
#include "moneybox.h"
#include <vector>
#include <algorithm>
#include <cmath>
using namespace std;

const int login_button_width = 12;
const int login_button_height = 3;

const int form_width = 36;
const int form_height = 3;

char login_button[login_button_height][login_button_width];
char signup_button[login_button_height][login_button_width];
char form[form_height][form_width];

const int KEY_UP = 72;
const int KEY_DOWN = 80;
const int KEY_LEFT = 75;
const int KEY_RIGHT = 77;

void save_accounts(const vector<bank_account>& bank_accounts);
void get_form() {
    int i, j;
    std::ifstream inputfile("form.txt");
    if (inputfile.is_open()) {
        std::string line;
        int line_number = 0;

        while (getline(inputfile, line) && line_number < form_height) {
            for (j = 0; j < line.length() && j < form_width; j++) {
                form[line_number][j] = line[j];
            }
            line_number++;
        }

        inputfile.close();
    }
    else {
        std::cout << "File could not open..." << std::endl;
    }
}
void get_login_button() {
    int i, j;
    std::ifstream inputfile("login-button.txt");
    if (inputfile.is_open()) {
        std::string line;
        int line_number = 0;

        while (getline(inputfile, line) && line_number < login_button_height) {
            for (j = 0; j < line.length() && j < login_button_width; j++) {
                login_button[line_number][j] = line[j];
            }
            line_number++;
        }

        inputfile.close();
    }
    else {
        std::cout << "File could not open..." << std::endl;
    }
}
void get_signup_button() {
    int i, j;
    std::ifstream inputfile("signup-button.txt");
    if (inputfile.is_open()) {
        std::string line;
        int line_number = 0;

        while (getline(inputfile, line) && line_number < login_button_height) {
            for (j = 0; j < line.length() && j < login_button_width; j++) {
                signup_button[line_number][j] = line[j];
            }
            line_number++;
        }

        inputfile.close();
    }
    else {
        std::cout << "File could not open..." << std::endl;
    }
}
void open_loading() {
    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    system("cls");
    SetConsoleCP(437);
    SetConsoleOutputCP(437);
    int bar1 = 177, bar2 = 219;


    COORD coord;
    coord.X = 24;
    coord.Y = 13;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "  WinBank";
    

    coord.X = 22;
    coord.Y = 33;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "@ Copyright 2023";
    coord.X = 13;
    coord.Y = 35;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "Powered by Jimmisteo | PIRAEUS BANK";
    

    coord.X = 17;
    coord.Y = 17;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    for (int i = 0; i < 25; i++) {
        cout << static_cast<char>(bar1);
    }

    
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);

    for (int i = 0; i < 25; i++) {
        cout << static_cast<char>(bar2);
        Sleep(150);
    }
    cursorInfo.bVisible = true;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
}
void create_loading() {
    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    system("cls");
    SetConsoleCP(437);
    SetConsoleOutputCP(437);
    int bar1 = 177, bar2 = 219;


    COORD coord;
    coord.X = 22;
    coord.Y = 8;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "  WinBank";

    coord.X = 19;
    coord.Y = 11;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "Creating your account...";

    coord.X = 13;
    coord.Y = 13;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "- This will only take a few seconds -";

    coord.X = 22;
    coord.Y = 33;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "@ Copyright 2023";
    coord.X = 13;
    coord.Y = 35;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "Powered by Jimmisteo | PIRAEUS BANK";


    coord.X = 17;
    coord.Y = 17;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    for (int i = 0; i < 25; i++) {
        cout << static_cast<char>(bar1);
    }


    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);

    for (int i = 0; i < 25; i++) {
        cout << static_cast<char>(bar2);
        Sleep(150);
    }
    cursorInfo.bVisible = true;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
}
bool login_singup() {
    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);

    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO consoleInfo;
    GetConsoleScreenBufferInfo(hConsole, &consoleInfo);
    WORD originalColor = consoleInfo.wAttributes;
    system("cls");
    COORD coord;
    coord.X = 24;
    coord.Y = 9;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "  WinBank";

    coord.X = 23;
    coord.Y = 13;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 0x2F);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 12; j++) {
            cout << login_button[i][j];
        }
    }

    coord.X = 23;
    coord.Y = 19;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 12; j++) {
            cout << signup_button[i][j];
        }
    }
    coord.X = 21;
    coord.Y = 15;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, originalColor);
    cout << ">";
    coord.X = 36;
    coord.Y = 15;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, originalColor);
    cout << "<";
    char choice;
    bool login_b = true;
    bool signup_b = false;
    coord.X = 22;
    coord.Y = 33;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "@ Copyright 2023";
    coord.X = 13;
    coord.Y = 35;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "Powered by Jimmisteo | PIRAEUS BANK";
    do {
        choice = _getch();
        switch (choice) {
        case KEY_UP:if (signup_b == true) {
                        signup_b = false;
                        login_b = true;
                        SetConsoleTextAttribute(hConsole, originalColor);
                        system("cls");
                        coord.X = 24;
                        coord.Y = 9;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        cout << "  WinBank";
                        coord.X = 23;
                        coord.Y = 13;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        SetConsoleTextAttribute(hConsole, 0x2F);
                        for (int i = 0; i < 3; i++) {
                            coord.Y++;
                            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                            for (int j = 0; j < 12; j++) {
                                cout << login_button[i][j];
                            }
                        }

                        coord.X = 23;
                        coord.Y = 19;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        SetConsoleTextAttribute(hConsole, 6);
                        for (int i = 0; i < 3; i++) {
                            coord.Y++;
                            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                            for (int j = 0; j < 12; j++) {
                                cout << signup_button[i][j];
                            }
                        }
                        coord.X = 21;
                        coord.Y = 15;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        SetConsoleTextAttribute(hConsole, originalColor);
                        cout << ">";
                        coord.X = 36;
                        coord.Y = 15;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        SetConsoleTextAttribute(hConsole, originalColor);
                        cout << "<";
                        coord.X = 22;
                        coord.Y = 33;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        cout << "@ Copyright 2023";
                        coord.X = 13;
                        coord.Y = 35;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        cout << "Powered by Jimmisteo | PIRAEUS BANK";
                    }

                   break;
        case KEY_DOWN:if (login_b == true) {
                        signup_b = true;
                        login_b = false;
                        SetConsoleTextAttribute(hConsole, originalColor);
                        system("cls");
                        coord.X = 24;
                        coord.Y = 9;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        cout << "  WinBank";
                        coord.X = 23;
                        coord.Y = 13;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        SetConsoleTextAttribute(hConsole, 6);
                        for (int i = 0; i < 3; i++) {
                            coord.Y++;
                            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                            for (int j = 0; j < 12; j++) {
                                cout << login_button[i][j];
                            }
                        }

                        coord.X = 23;
                        coord.Y = 19;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        SetConsoleTextAttribute(hConsole, 0x2F); 
                        for (int i = 0; i < 3; i++) {
                            coord.Y++;
                            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                            for (int j = 0; j < 12; j++) {
                                cout << signup_button[i][j];
                            }
                        }
                        coord.X = 21;
                        coord.Y = 21;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        SetConsoleTextAttribute(hConsole, originalColor);
                        cout << ">";
                        coord.X = 36;
                        coord.Y = 21;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        SetConsoleTextAttribute(hConsole, originalColor);
                        cout << "<";
                        coord.X = 22;
                        coord.Y = 33;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        cout << "@ Copyright 2023";
                        coord.X = 13;
                        coord.Y = 35;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        cout << "Powered by Jimmisteo | PIRAEUS BANK";
                    }
                     break;
        }
    } while (choice !='\r');
    SetConsoleTextAttribute(hConsole, originalColor);
    return login_b;
}
void login(vector<bank_account> &bank_accounts,int &li,bool &yes) {
    int console_width = 60;
    int console_height = 40;

    HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
    SMALL_RECT rect;
    COORD coordinates;

    rect.Left = 0;
    rect.Top = 0;
    rect.Right = console_width - 1;
    rect.Bottom = console_height - 1;

    SetConsoleWindowInfo(console, TRUE, &rect);

    coordinates.X = console_width;
    coordinates.Y = console_height;
    SetConsoleScreenBufferSize(console, coordinates);

    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO consoleInfo;
    GetConsoleScreenBufferInfo(hConsole, &consoleInfo);
    WORD originalColor = consoleInfo.wAttributes;
    SetConsoleTextAttribute(hConsole, originalColor);

    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = true;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    system("cls");  
    COORD coord;
    coord.X = 15;
    coord.Y = 9;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "  WinBank | Login Page";

    coord.X = 12;
    coord.Y = 12;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "Email";

    coord.X = 12;
    coord.Y = 18;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "Password";

    coord.X = 12;
    coord.Y = 12;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 35; j++) {
            cout << form[i][j];
        }
    }

    coord.X = 12; 
    coord.Y = 18;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 35; j++) {
            cout << form[i][j];
        }
    }

    coord.X = 23;
    coord.Y = 24;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 0x2F);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 12; j++) {
            cout << login_button[i][j];
        }
    }


    string usernafme;
    string password;
    coord.X = 22;
    coord.Y = 33;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, originalColor);
    cout << "@ Copyright 2023";
    coord.X = 13;
    coord.Y = 35;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "Powered by Jimmisteo | PIRAEUS BANK";

    SetConsoleTextAttribute(hConsole, 6);

    coord.X = 14;
    coord.Y = 14;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cin >> usernafme;

    coord.X = 14;
    coord.Y = 20;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cin >> password;

    SetConsoleTextAttribute(hConsole, originalColor);
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);

    yes = true;

    coord.X = 12;
    coord.Y = 23;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "Remember me";

    coord.X = 26;
    coord.Y = 23;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 0x2F);
    cout << "YES";

    coord.X = 33;
    coord.Y = 23;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << "NO";

    coord.X = 25;
    coord.Y = 23;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, originalColor);
    cout << ">";

    coord.X = 29;
    coord.Y = 23;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, originalColor);
    cout << "<";

    char rem;
    do {
        coord.X = 25;
        coord.Y = 23;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        rem = _getch();
        if (rem == KEY_RIGHT && yes == true) {
            yes = false;

            system("cls");
            coord.X = 15;
            coord.Y = 9;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "  WinBank | Login Page";

            coord.X = 12;
            coord.Y = 12;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "Email";

            coord.X = 12;
            coord.Y = 18;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "Password";

            coord.X = 12;
            coord.Y = 12;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 6);
            for (int i = 0; i < 3; i++) {
                coord.Y++;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                for (int j = 0; j < 35; j++) {
                    cout << form[i][j];
                }
            }

            coord.X = 12;
            coord.Y = 18;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 6);
            for (int i = 0; i < 3; i++) {
                coord.Y++;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                for (int j = 0; j < 35; j++) {
                    cout << form[i][j];
                }
            }

            coord.X = 23;
            coord.Y = 24;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 0x2F);
            for (int i = 0; i < 3; i++) {
                coord.Y++;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                for (int j = 0; j < 12; j++) {
                    cout << login_button[i][j];
                }
            }


            
            coord.X = 22;
            coord.Y = 33;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, originalColor);
            cout << "@ Copyright 2023";
            coord.X = 13;
            coord.Y = 35;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "Powered by Jimmisteo | PIRAEUS BANK";

            SetConsoleTextAttribute(hConsole, 6);

            coord.X = 14;
            coord.Y = 14;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << usernafme;

            coord.X = 14;
            coord.Y = 20;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << password;

            SetConsoleTextAttribute(hConsole, originalColor);
            cursorInfo.bVisible = false;
            SetConsoleCursorInfo(consoleHandle, &cursorInfo);

            

            coord.X = 12;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "Remember me";

            coord.X = 26;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 6);
            cout << "YES";

            coord.X = 33;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord); 
            SetConsoleTextAttribute(hConsole, 0x2F);
            cout << "NO";

            coord.X = 32;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, originalColor);
            cout << ">";

            coord.X = 35;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, originalColor);
            cout << "<";
        }
        else if (rem == KEY_LEFT && yes == false) {
            yes = true;
            system("cls");
            coord.X = 15;
            coord.Y = 9;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "  WinBank | Login Page";

            coord.X = 12;
            coord.Y = 12;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "Email";

            coord.X = 12;
            coord.Y = 18;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "Password";

            coord.X = 12;
            coord.Y = 12;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 6);
            for (int i = 0; i < 3; i++) {
                coord.Y++;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                for (int j = 0; j < 35; j++) {
                    cout << form[i][j];
                }
            }

            coord.X = 12;
            coord.Y = 18;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 6);
            for (int i = 0; i < 3; i++) {
                coord.Y++;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                for (int j = 0; j < 35; j++) {
                    cout << form[i][j];
                }
            }

            coord.X = 23;
            coord.Y = 24;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 0x2F);
            for (int i = 0; i < 3; i++) {
                coord.Y++;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                for (int j = 0; j < 12; j++) {
                    cout << login_button[i][j];
                }
            }


            
            coord.X = 22;
            coord.Y = 33;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, originalColor);
            cout << "@ Copyright 2023";
            coord.X = 13;
            coord.Y = 35;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "Powered by Jimmisteo | PIRAEUS BANK";

            SetConsoleTextAttribute(hConsole, 6);

            coord.X = 14;
            coord.Y = 14;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << usernafme;

            coord.X = 14;
            coord.Y = 20;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << password;

            SetConsoleTextAttribute(hConsole, originalColor);
            cursorInfo.bVisible = false;
            SetConsoleCursorInfo(consoleHandle, &cursorInfo);

            

            coord.X = 12;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "Remember me";

            coord.X = 26;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 0x2F);
            cout << "YES";

            coord.X = 33;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 6);
            cout << "NO";

            coord.X = 25;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, originalColor);
            cout << ">";

            coord.X = 29;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, originalColor);
            cout << "<";
        }
    } while (rem != '\r');

    coord.X = 32;
    coord.Y = 23;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, originalColor);
    cout << " ";

    coord.X = 35;
    coord.Y = 23;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, originalColor);
    cout << " ";

    coord.X = 25;
    coord.Y = 23;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, originalColor);
    cout << " ";

    coord.X = 29;
    coord.Y = 23;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, originalColor);
    cout << " ";

    coord.X = 21;
    coord.Y = 26;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << ">";

    coord.X = 36;
    coord.Y = 26;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "<";

    coord.X = 4;
    coord.Y = 6;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "!TIP : To re-Type your details press the UP-ARROW";
    SetConsoleTextAttribute(hConsole, originalColor);
    char l;
    bool p_form=false, u_form=false, b_form=true,ufound=false,efound=false;
    do {
        coord.X = 39;
        coord.Y = 26;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        l = _getch();
        switch (l) {
        case KEY_UP:if (b_form == true) {
            
            SetConsoleTextAttribute(hConsole, originalColor);
            system("cls");
            coord.X = 15;
            coord.Y = 9;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "  WinBank | Login Page";

            coord.X = 12;
            coord.Y = 12;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "Email";

            coord.X = 12;
            coord.Y = 18;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "Password";

            coord.X = 12;
            coord.Y = 12;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 6);
            for (int i = 0; i < 3; i++) {
                coord.Y++;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                for (int j = 0; j < 35; j++) {
                    cout << form[i][j];
                }
            }

            coord.X = 12;
            coord.Y = 18;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 6);
            for (int i = 0; i < 3; i++) {
                coord.Y++;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                for (int j = 0; j < 35; j++) {
                    cout << form[i][j];
                }
            }

            coord.X = 23;
            coord.Y = 24;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 0x2F);
            for (int i = 0; i < 3; i++) {
                coord.Y++;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                for (int j = 0; j < 12; j++) {
                    cout << login_button[i][j];
                }
            }


           
            coord.X = 22;
            coord.Y = 33;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, originalColor);
            cout << "@ Copyright 2023";
            coord.X = 13;
            coord.Y = 35;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "Powered by Jimmisteo | PIRAEUS BANK";
            cursorInfo.bVisible = true;
            SetConsoleCursorInfo(consoleHandle, &cursorInfo);
            SetConsoleTextAttribute(hConsole, originalColor);
            coord.X = 10;
            coord.Y = 14;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << ">";

            coord.X = 49;
            coord.Y = 14;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "<";

            SetConsoleTextAttribute(hConsole, 6);
            cursorInfo.bVisible = true;
            coord.X = 14;
            coord.Y = 14;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cin >> usernafme;
            SetConsoleTextAttribute(hConsole, originalColor);
            coord.X = 10;
            coord.Y = 14;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << " ";

            coord.X = 49;
            coord.Y = 14;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << " ";
            SetConsoleTextAttribute(hConsole, originalColor);
            coord.X = 10;
            coord.Y = 20;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << ">";

            coord.X = 49;
            coord.Y = 20;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "<";
            SetConsoleTextAttribute(hConsole, 6);
            
            SetConsoleCursorInfo(consoleHandle, &cursorInfo);
            coord.X = 14;
            coord.Y = 20;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cin >> password;

            SetConsoleTextAttribute(hConsole, originalColor);
            coord.X = 10;
            coord.Y = 20;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << " ";

            coord.X = 49;
            coord.Y = 20;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << " ";
            SetConsoleTextAttribute(hConsole, originalColor);
            cursorInfo.bVisible = false;
            SetConsoleCursorInfo(consoleHandle, &cursorInfo);

            yes = true;
            coord.X = 12;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "Remember me";

            coord.X = 26;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 0x2F);
            cout << "YES";

            coord.X = 33;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 6);
            cout << "NO";

            coord.X = 25;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, originalColor);
            cout << ">";

            coord.X = 29;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, originalColor);
            cout << "<";

            
            do {
                coord.X = 25;
                coord.Y = 23;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                rem = _getch();
                if (rem == KEY_RIGHT && yes == true) {
                    yes = false;

                    system("cls");
                    coord.X = 15;
                    coord.Y = 9;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << "  WinBank | Login Page";

                    coord.X = 12;
                    coord.Y = 12;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << "Email";

                    coord.X = 12;
                    coord.Y = 18;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << "Password";

                    coord.X = 12;
                    coord.Y = 12;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, 6);
                    for (int i = 0; i < 3; i++) {
                        coord.Y++;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        for (int j = 0; j < 35; j++) {
                            cout << form[i][j];
                        }
                    }

                    coord.X = 12;
                    coord.Y = 18;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, 6);
                    for (int i = 0; i < 3; i++) {
                        coord.Y++;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        for (int j = 0; j < 35; j++) {
                            cout << form[i][j];
                        }
                    }

                    coord.X = 23;
                    coord.Y = 24;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, 0x2F);
                    for (int i = 0; i < 3; i++) {
                        coord.Y++;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        for (int j = 0; j < 12; j++) {
                            cout << login_button[i][j];
                        }
                    }



                    coord.X = 22;
                    coord.Y = 33;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, originalColor);
                    cout << "@ Copyright 2023";
                    coord.X = 13;
                    coord.Y = 35;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << "Powered by Jimmisteo | PIRAEUS BANK";

                    SetConsoleTextAttribute(hConsole, 6);

                    coord.X = 14;
                    coord.Y = 14;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << usernafme;

                    coord.X = 14;
                    coord.Y = 20;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << password;

                    SetConsoleTextAttribute(hConsole, originalColor);
                    cursorInfo.bVisible = false;
                    SetConsoleCursorInfo(consoleHandle, &cursorInfo);



                    coord.X = 12;
                    coord.Y = 23;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << "Remember me";

                    coord.X = 26;
                    coord.Y = 23;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, 6);
                    cout << "YES";

                    coord.X = 33;
                    coord.Y = 23;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, 0x2F);
                    cout << "NO";

                    coord.X = 32;
                    coord.Y = 23;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, originalColor);
                    cout << ">";

                    coord.X = 35;
                    coord.Y = 23;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, originalColor);
                    cout << "<";
                }
                else if (rem == KEY_LEFT && yes == false) {
                    yes = true;
                    system("cls");
                    coord.X = 15;
                    coord.Y = 9;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << "  WinBank | Login Page";

                    coord.X = 12;
                    coord.Y = 12;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << "Email";

                    coord.X = 12;
                    coord.Y = 18;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << "Password";

                    coord.X = 12;
                    coord.Y = 12;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, 6);
                    for (int i = 0; i < 3; i++) {
                        coord.Y++;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        for (int j = 0; j < 35; j++) {
                            cout << form[i][j];
                        }
                    }

                    coord.X = 12;
                    coord.Y = 18;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, 6);
                    for (int i = 0; i < 3; i++) {
                        coord.Y++;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        for (int j = 0; j < 35; j++) {
                            cout << form[i][j];
                        }
                    }

                    coord.X = 23;
                    coord.Y = 24;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, 0x2F);
                    for (int i = 0; i < 3; i++) {
                        coord.Y++;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        for (int j = 0; j < 12; j++) {
                            cout << login_button[i][j];
                        }
                    }



                    coord.X = 22;
                    coord.Y = 33;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, originalColor);
                    cout << "@ Copyright 2023";
                    coord.X = 13;
                    coord.Y = 35;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << "Powered by Jimmisteo | PIRAEUS BANK";

                    SetConsoleTextAttribute(hConsole, 6);

                    coord.X = 14;
                    coord.Y = 14;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << usernafme;

                    coord.X = 14;
                    coord.Y = 20;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << password;

                    SetConsoleTextAttribute(hConsole, originalColor);
                    cursorInfo.bVisible = false;
                    SetConsoleCursorInfo(consoleHandle, &cursorInfo);


                    
                    coord.X = 12;
                    coord.Y = 23;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << "Remember me";

                    coord.X = 26;
                    coord.Y = 23;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, 0x2F);
                    cout << "YES";

                    coord.X = 33;
                    coord.Y = 23;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, 6);
                    cout << "NO";

                    coord.X = 25;
                    coord.Y = 23;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, originalColor);
                    cout << ">";

                    coord.X = 29;
                    coord.Y = 23;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    SetConsoleTextAttribute(hConsole, originalColor);
                    cout << "<";
                }
            } while (rem != '\r');

            coord.X = 32;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, originalColor);
            cout << " ";

            coord.X = 35;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, originalColor);
            cout << " ";

            coord.X = 25;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, originalColor);
            cout << " ";

            coord.X = 29;
            coord.Y = 23;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, originalColor);
            cout << " ";

            coord.X = 21;
            coord.Y = 26;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << ">";

            coord.X = 36;
            coord.Y = 26;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << "<";
            
            coord.X = 4;
            coord.Y = 6;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 96);
            cout << "!TIP : To re-Type your details press the UP-ARROW";
            SetConsoleTextAttribute(hConsole, originalColor);
        }
            break;
        case '\r':
            for (int i = 0; i < bank_accounts.size(); i++) {
                if (usernafme != bank_accounts[i].email || password != bank_accounts[i].password) {
                    efound = true;
                    
                }
                else if (usernafme == bank_accounts[i].email && password == bank_accounts[i].password) {
                    efound = false;
                    li = i;
                    break;
                }
            }
            if (efound == true) {
                coord.X = 11;
                coord.Y = 30;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 100);
                cout << "!Wrong Email or Password,try again...";
                l = '1';
            }

        }
    } while (l != '\r');

}
void signup(vector<bank_account> &bank_accounts) {

    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = true;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);

    int console_width = 60;
    int console_height = 61;

    HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
    SMALL_RECT rect;
    COORD coordinates;

    rect.Left = 0;
    rect.Top = 0;
    rect.Right = console_width - 1;
    rect.Bottom = console_height - 1;

    SetConsoleWindowInfo(console, TRUE, &rect);

    coordinates.X = console_width;
    coordinates.Y = console_height;
    SetConsoleScreenBufferSize(console, coordinates);
    system("cls");
    COORD coord;
    coord.X = 12;
    coord.Y = 2;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);

    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "  WinBank | Sign-Up Page";

    coord.X = 12;
    coord.Y = 4;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "First Name *";
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 35; j++) {
            cout << form[i][j];
        }
    }
    coord.X = 12;
    coord.Y = 9;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "Last Name *";
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 35; j++) {
            cout << form[i][j];
        }
    }
    coord.X = 12;
    coord.Y = 14;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "Email *";
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 35; j++) {
            cout << form[i][j];
        }
    }
    coord.X = 12;
    coord.Y = 19;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "New Password *";
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 35; j++) {
            cout << form[i][j];
        }
    }
    coord.X = 12;
    coord.Y = 24;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "Confirm Password *";
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 35; j++) {
            cout << form[i][j];
        }
    }
    coord.X = 12;
    coord.Y = 29;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "Id Number *";
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 35; j++) {
            cout << form[i][j];
        }
    }
    coord.X = 12;
    coord.Y = 34;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "AFM *";
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 35; j++) {
            cout << form[i][j];
        }
    }
    coord.X = 12;
    coord.Y = 39;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "Birth Date *";
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 35; j++) {
            cout << form[i][j];
        }
    }
    coord.X = 14;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << "00/00/0000";
    
    coord.X = 12;
    coord.Y = 44;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "Monthly Income *";
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 35; j++) {
            cout << form[i][j];
        }
    }
    SetConsoleTextAttribute(hConsole, 96);
    coord.X = 23;
    coord.Y = 50;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    for (int i = 0; i < 3; i++) {
        coord.Y++;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        for (int j = 0; j < 12; j++) {
            cout << signup_button[i][j];
        }
    }

    coord.X = 22;
    coord.Y = 56;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "@ Copyright 2023";
    coord.X = 13;
    coord.Y = 58;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "Powered by Jimmisteo | PIRAEUS BANK";
    
    string first_name, last_name, email, password,new_password, id, afm;
    char date[8];
    int income;
    
    coord.X = 12;
    coord.Y = 1;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);

    coord.X = 14;
    coord.Y = 6;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cin >> first_name;

    coord.X = 14;
    coord.Y = 11;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cin >> last_name;
    bool email_found=false;
    do {
        cursorInfo.bVisible = true;
        SetConsoleCursorInfo(consoleHandle, &cursorInfo);
        email_found = false;
        coord.X = 14;
        coord.Y = 16;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        SetConsoleTextAttribute(hConsole, 6);
        cin >> email;
        for (int i = 0; i < bank_accounts.size(); i++) {
            if (bank_accounts[i].email == email) {
                email_found = true;
                cursorInfo.bVisible = false;
                SetConsoleCursorInfo(consoleHandle, &cursorInfo);
                coord.X = 30;
                coord.Y = 14;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 100);
                cout << "Email already exists!";
                Sleep(2500);
                coord.X = 30;
                coord.Y = 14;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 100);
                cout << "                           ";
                coord.X = 14;
                coord.Y = 16;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 6);
                cout << "                                 ";
            }
        }
    } while (email_found == true);

    coord.X = 14;
    coord.Y = 21;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cin >> password;

    bool safme_pass = true;

    do {
        cursorInfo.bVisible = true;
        SetConsoleCursorInfo(consoleHandle, &cursorInfo);
        safme_pass = true;
        coord.X = 14;
        coord.Y = 26;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        SetConsoleTextAttribute(hConsole, 6);
        cin >> new_password;
        if (new_password != password) {
            cursorInfo.bVisible = false;
            SetConsoleCursorInfo(consoleHandle, &cursorInfo);
            safme_pass = false;
            coord.X = 31;
            coord.Y = 24;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 100);
            cout << "Wrong Password!";
            Sleep(2500);
            coord.X = 31;
            coord.Y = 24;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 100);
            cout << "                ";
            coord.X = 14;
            coord.Y = 26;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            SetConsoleTextAttribute(hConsole, 6);
            cout << "                                 ";

        }
    } while (safme_pass == false);

    coord.X = 12;
    coord.Y = 43;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);

    coord.X = 14;
    coord.Y = 31;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cin >> id;

    bool afm_found=false;

    do {
        cursorInfo.bVisible = true;
        SetConsoleCursorInfo(consoleHandle, &cursorInfo);
        afm_found = false;
        coord.X = 14;
        coord.Y = 36;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        SetConsoleTextAttribute(hConsole, 6);
        cin >> afm;
        for (int i = 0; i < bank_accounts.size(); i++) {
            if (afm == bank_accounts[i].afm) {
                cursorInfo.bVisible = false;
                SetConsoleCursorInfo(consoleHandle, &cursorInfo);
                afm_found = true;
                coord.X = 17;
                coord.Y = 34;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 100);
                cout << "This AFM belongs to another person!";
                Sleep(2500);
                coord.X = 17;
                coord.Y = 34;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 100);
                cout << "                                    ";
                coord.X = 14;
                coord.Y = 36;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 6);
                cout << "                                ";

            }
        }
    } while (afm_found == true);

    coord.X = 12;
    coord.Y = 55;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);

    coord.X = 14;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    date[0] = _getch();
    coord.X = 14;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << date[0];
    coord.X = 15;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    date[1] = _getch();
    coord.X = 15;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << date[1];
    coord.X = 17;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    date[2] = _getch();
    coord.X = 17;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << date[2];
    coord.X = 18;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    date[3] = _getch();
    coord.X = 18;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << date[3];
    coord.X = 20;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    date[4] = _getch();
    coord.X = 20;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << date[4];
    coord.X = 21;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    date[5] = _getch();
    coord.X = 21;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << date[5];
    coord.X = 22;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    date[6] = _getch();
    coord.X = 22;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << date[6];
    coord.X = 23;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    date[7] = _getch();
    coord.X = 23;
    coord.Y = 41;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cout << date[7];
   


    coord.X = 14;
    coord.Y = 46;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 6);
    cin >> income;

    coord.X = 21;
    coord.Y = 60;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);

    coord.X = 21;
    coord.Y = 52;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << ">";
    coord.X = 36;
    coord.Y = 52;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "<";
    char  s;
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    do {
        coord.X = 42;
        coord.Y = 50;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        SetConsoleTextAttribute(hConsole, 96);
        
        s = _getch();

    } while (s!='\r');


    bank_account acc;
    acc.first_name = first_name;
    acc.last_name = last_name;
    acc.email = email;
    acc.password = password;
    acc.id_number = id;
    acc.afm = afm;
    acc.birth_date[0] = date[0];
    acc.birth_date[1] = date[1];
    acc.birth_date[2] = date[2];
    acc.birth_date[3] = date[3];
    acc.birth_date[4] = date[4];
    acc.birth_date[5] = date[5];
    acc.birth_date[6] = date[6];
    acc.birth_date[7] = date[7];

    acc.income = income;
    acc.remember = false;
    bank_accounts.push_back(acc);
    save_accounts(bank_accounts);
    SetConsoleTextAttribute(hConsole, 96);
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    create_loading();

    system("cls");

    coord.X = 16;
    coord.Y = 10;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "  WinBank";

    coord.X = 8;
    coord.Y = 14;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 96);
    cout << "Your has been created successfully!";

    for (int i = 0; i < 5; i++) {
        coord.X = 8;
        coord.Y = 16;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        SetConsoleTextAttribute(hConsole, 96);
        cout << "You can login in " << 5 - i << " seconds.";
        Sleep(1000);
    }



}
void save_accounts(const vector<bank_account>& bank_accounts) {
    std::ofstream outfile("accounts.txt");
    if (outfile.is_open()) {
        for (const bank_account acc : bank_accounts) {

            outfile << acc.first_name << "," << acc.last_name << "," << acc.email << "," << acc.password << "," << acc.id_number << "," << acc.afm << "," << acc.birth_date << "," << acc.income << "," << acc.balance << "," << acc.remember << "," << acc.card1_number << "," << acc.card2_number << "," << acc.full_iban << "," << acc.short_iban << "\n";
           


        }
        outfile.close();
    }
    else {
        std::cout << "Error: Unable to save accounts." << std::endl;
    }
}
void save_money_boxes(const vector<moneybox>& moneyboxes) {
    std::ofstream outfile("moneyboxes.txt");
    if (outfile.is_open()) {
        for (const moneybox mbox : moneyboxes) {

            outfile << mbox.email << "," << mbox.box_name << "," << mbox.goal << "," << mbox.saved << "," << mbox.end_date[0] << mbox.end_date[1] << "/" << mbox.end_date[2] << mbox.end_date[3] << "/" << mbox.end_date[4] << mbox.end_date[5] << mbox.end_date[6] << mbox.end_date[7] << "," << mbox.category << "\n";



        }
        outfile.close();
    }
    else {
        std::cout << "Error: Unable to save accounts." << std::endl;
    }
}
void load_accounts(std::vector<bank_account>& bank_accounts) {
    std::ifstream infile("accounts.txt");
    if (infile.is_open()) {
        std::string line;
        while (std::getline(infile, line)) {
            bank_account acc;
            size_t pos = 0;
            std::string token;


            for (int i = 0; i < 14; i++) {
                pos = line.find(",");
                token = line.substr(0, pos);
                switch (i) {
                case 0:
                    acc.first_name = token;
                    break;
                case 1:
                    acc.last_name = token;
                    break;
                case 2:
                    acc.email = token;
                    break;
                case 3:
                    acc.password = token;
                    break;
                case 4:
                    acc.id_number = token;
                    break;
                case 5:
                    acc.afm = token;
                    break;
                case 6:
                    acc.birth_date = token;
                    break;
                case 7:
                    acc.income = stoll(token);
                    break;
                case 8:
                    acc.balance = stoll(token);
                    break;
                case 9 :
                    acc.remember = (token == "1");
                    break;
                case 10:
                    acc.card1_number = token;
                    break;
                case 11:
                    acc.card1_number = token;
                    break;
                case 12:
                    acc.full_iban = token;
                    break;
                case 13:
                    acc.short_iban = token;
                    break;

                }
                line.erase(0, pos + 1);
            }
            bank_accounts.push_back(acc);
        }
        infile.close();
    }
    else {
        std::cout << "Error: Unable to load accounts." << std::endl;
    }
}
void load_moneyboxes(std::vector<moneybox>& moneyboxes) {
    std::ifstream infile("moneyboxes.txt");
    if (infile.is_open()) {
        std::string line;
        while (std::getline(infile, line)) {
            moneybox mbox;
            size_t pos = 0;
            std::string token;


            for (int i = 0; i < 6; i++) {
                pos = line.find(",");
                token = line.substr(0, pos);
                switch (i) {
                case 0:
                    mbox.email = token;
                    break;
                case 1:
                    mbox.box_name = token;
                    break;
                case 2:
                    mbox.goal = stold(token);
                    break;
                case 3:
                    mbox.saved = stold(token);
                    break;
                case 4:
                    mbox.end_date[0] = token[0];
                    mbox.end_date[1] = token[1];
                    mbox.end_date[2] = token[3];
                    mbox.end_date[3] = token[4];
                    mbox.end_date[4] = token[6];
                    mbox.end_date[5] = token[7];
                    mbox.end_date[6] = token[8];
                    mbox.end_date[7] = token[9];
                    break;
                case 5:
                    mbox.category = token;
                    break;
                

                }
                line.erase(0, pos + 1);
            }
            moneyboxes.push_back(mbox);
        }
        infile.close();
    }
    else {
        std::cout << "Error: Unable to load accounts." << std::endl;
    }
}
void show_home(vector<bank_account> &bank_accounts,int li,vector<moneybox> &moneyboxes, char& move) {

    std::transform(bank_accounts[li].first_name.begin(), bank_accounts[li].first_name.end(), bank_accounts[li].first_name.begin(), [](unsigned char c) {
        return std::toupper(c);
        });
    std::transform(bank_accounts[li].last_name.begin(), bank_accounts[li].last_name.end(), bank_accounts[li].last_name.begin(), [](unsigned char c) {
        return std::toupper(c);
        });

    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO consoleInfo;
    GetConsoleScreenBufferInfo(hConsole, &consoleInfo);
    WORD originalColor = 111;
    SetConsoleTextAttribute(hConsole, originalColor);

    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    SetConsoleTextAttribute(hConsole, 127);
    system("cls");
    
    COORD coord;
    SetConsoleTextAttribute(hConsole, originalColor);
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 60; j++) {
            coord.X = j;
            coord.Y = i;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << " ";
        }
    }
   
    coord.X = 3;
    coord.Y = 1;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, originalColor);
    cout << "You are logged in as";

    coord.X = 3;
    coord.Y = 2;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, originalColor);
    cout << bank_accounts[li].first_name  << " " << bank_accounts[li].last_name;


    
    SetConsoleTextAttribute(hConsole, 246);
    for (int i = 6; i < 13; i++) {
        for (int j = 4; j < 57; j++) {
            coord.X = j;
            coord.Y = i;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << " ";
        }
    }

    coord.X = 6;
    coord.Y = 7;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << "Accounts";


    coord.X = 6;
    coord.Y = 9;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << bank_accounts[li].full_iban;

    coord.X = 43;
    coord.Y = 9;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << "Available";

    coord.X = 6;
    coord.Y = 11;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << bank_accounts[li].short_iban;

    coord.X = 44;
    coord.Y = 11;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    double intPart;
    double fractionalPart = modf(bank_accounts[li].balance, &intPart);

    if (fractionalPart == 0.0) {
        cout << bank_accounts[li].balance << ".00 $";
    }
    else {
        cout << bank_accounts[li].balance << " $";
    }



    SetConsoleTextAttribute(hConsole, 246);
    for (int i = 15; i < 24; i++) {
        for (int j = 4; j < 57; j++) {
            coord.X = j;
            coord.Y = i;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << " ";
        }
    }

    coord.X = 6;
    coord.Y = 16;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << "Cards";


    coord.X = 6;
    coord.Y = 18;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << "Debit Mastercard";

    coord.X = 43;
    coord.Y = 18;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << "Available";

    coord.X = 6;
    coord.Y = 19;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << bank_accounts[li].card1_number;

    coord.X = 44;
    coord.Y = 19;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << "0.00 $";

    coord.X = 6;
    coord.Y = 21;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << "Virtual MC Card";

    coord.X = 43;
    coord.Y = 21;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << "Available";

    coord.X = 6;
    coord.Y = 22;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << bank_accounts[li].card2_number;

    coord.X = 44;
    coord.Y = 22;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << "0.00 $";
    

    SetConsoleTextAttribute(hConsole, 246);
    for (int i = 26; i < 34; i++) {
        for (int j = 4; j < 57; j++) {
            coord.X = j;
            coord.Y = i;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << " ";
        }
    }
    
    coord.X = 6;
    coord.Y = 27;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << "Money Boxes";
    bool box_found=false;
    int l=-1;
    for (int i = 0; i < moneyboxes.size(); i++) {
        if (moneyboxes[i].email == bank_accounts[li].email) {
            box_found = true;
            l = i;
            break;
        }
    }

    if (box_found == false) {
        coord.X = 6;
        coord.Y = 29;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        cout << "Do you want to set a savings goal and save money";
        coord.X = 6;
        coord.Y = 30;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        cout << "easily?";

        coord.X = 6;
        coord.Y = 32;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        cout << "Open a Money Box now!";
    }
    else {
        coord.X = 23;
        coord.Y = 27;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        cout << moneyboxes[l].box_name << " - " << moneyboxes[l].category ;

        coord.X = 17;
        coord.Y = 29;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        cout << "Goal";

        coord.X = 37;
        coord.Y = 29;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        cout << "Saved";

        coord.X = 17;
        coord.Y = 30;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        intPart;
        fractionalPart = modf(moneyboxes[l].goal, &intPart);

        if (fractionalPart == 0.0) {
            cout << moneyboxes[l].goal << ".00 $";
        }
        else {
            cout << moneyboxes[l].goal << " $";
        }
        

        coord.X = 37;
        coord.Y = 30;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        intPart;
        fractionalPart = modf(moneyboxes[l].saved, &intPart);

        if (fractionalPart == 0.0) {
            cout << moneyboxes[l].saved << ".00 $";
        }
        else {
            cout << moneyboxes[l].saved << " $";
        }
        
        coord.X = 6;
        coord.Y = 32;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        cout << "Expires at : " << moneyboxes[l].end_date[0] << moneyboxes[l].end_date[1] << "/" << moneyboxes[l].end_date[2] << moneyboxes[l].end_date[3] << "/" <<  moneyboxes[l].end_date[4] << moneyboxes[l].end_date[5] << moneyboxes[l].end_date[6] << moneyboxes[l].end_date[7];
    }
    SetConsoleTextAttribute(hConsole, originalColor);
    for (int i = 37; i < 40; i++) {
        for (int j = 0; j < 60; j++) {
            coord.X = j;
            coord.Y = i;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << " ";
        }
    }
    coord.X = 4;
    coord.Y = 38;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "Home";

    coord.X = 3;
    coord.Y = 37;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "______";

    SetConsoleTextAttribute(hConsole, 104);

    coord.X = 12;
    coord.Y = 38;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "Statistics";

    coord.X = 26;
    coord.Y = 38;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "Transfers";

    coord.X = 39;
    coord.Y = 38;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "Payments";

    coord.X = 51;
    coord.Y = 38;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    cout << "Profile";

    bool acc_tab = true, cards_tab = false, box_tab = false;

    if (move == KEY_UP) {
        SetConsoleTextAttribute(hConsole, 111);
        for (int i = 6; i < 13; i++) {
            for (int j = 4; j < 57; j++) {
                coord.X = j;
                coord.Y = i;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                cout << " ";
            }
        }

        coord.X = 6;
        coord.Y = 7;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        SetConsoleTextAttribute(hConsole, 111);
        cout << "Accounts";


        coord.X = 6;
        coord.Y = 9;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        SetConsoleTextAttribute(hConsole, 111);
        cout << bank_accounts[li].full_iban;

        coord.X = 43;
        coord.Y = 9;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        SetConsoleTextAttribute(hConsole, 111);
        cout << "Available";

        coord.X = 6;
        coord.Y = 11;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        SetConsoleTextAttribute(hConsole, 111);
        cout << bank_accounts[li].short_iban;

        coord.X = 44;
        coord.Y = 11;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        SetConsoleTextAttribute(hConsole, 111);
        double intPart;
        double fractionalPart = modf(bank_accounts[li].balance, &intPart);

        if (fractionalPart == 0.0) {
            cout << bank_accounts[li].balance << ".00 $";
        }
        else {
            cout << bank_accounts[li].balance << " $";
        }
        char m;
        do {
            m = _getch();
            switch (m) {
            case KEY_DOWN:if (acc_tab == true) {
                acc_tab = false;
                cards_tab = true;
                SetConsoleTextAttribute(hConsole, 246);
                for (int i = 6; i < 13; i++) {
                    for (int j = 4; j < 57; j++) {
                        coord.X = j;
                        coord.Y = i;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        cout << " ";
                    }
                }

                coord.X = 6;
                coord.Y = 7;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 246);
                cout << "Accounts";


                coord.X = 6;
                coord.Y = 9;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 246);
                cout << bank_accounts[li].full_iban;

                coord.X = 43;
                coord.Y = 9;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 246);
                cout << "Available";

                coord.X = 6;
                coord.Y = 11;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 246);
                cout << bank_accounts[li].short_iban;

                coord.X = 44;
                coord.Y = 11;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 246);
                intPart;
                fractionalPart = modf(bank_accounts[li].balance, &intPart);

                if (fractionalPart == 0.0) {
                    cout << bank_accounts[li].balance << ".00 $";
                }
                else {
                    cout << bank_accounts[li].balance << " $";
                }

                SetConsoleTextAttribute(hConsole, 111);
                for (int i = 15; i < 24; i++) {
                    for (int j = 4; j < 57; j++) {
                        coord.X = j;
                        coord.Y = i;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        cout << " ";
                    }
                }

                coord.X = 6;
                coord.Y = 16;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 111);
                cout << "Cards";


                coord.X = 6;
                coord.Y = 18;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 111);
                cout << "Debit Mastercard";

                coord.X = 43;
                coord.Y = 18;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 111);
                cout << "Available";

                coord.X = 6;
                coord.Y = 19;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 111);
                cout << bank_accounts[li].card1_number;

                coord.X = 44;
                coord.Y = 19;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 111);
                cout << "0.00 $";

                coord.X = 6;
                coord.Y = 21;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 111);
                cout << "Virtual MC Card";

                coord.X = 43;
                coord.Y = 21;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 111);
                cout << "Available";

                coord.X = 6;
                coord.Y = 22;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 111);
                cout << bank_accounts[li].card2_number;

                coord.X = 44;
                coord.Y = 22;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 111);
                cout << "0.00 $";
            }
                         else if (cards_tab == true) {
                cards_tab = false;
                box_tab = true;
                SetConsoleTextAttribute(hConsole, 246);
                for (int i = 15; i < 24; i++) {
                    for (int j = 4; j < 57; j++) {
                        coord.X = j;
                        coord.Y = i;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        cout << " ";
                    }
                }

                coord.X = 6;
                coord.Y = 16;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 246);
                cout << "Cards";


                coord.X = 6;
                coord.Y = 18;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 246);
                cout << "Debit Mastercard";

                coord.X = 43;
                coord.Y = 18;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 246);
                cout << "Available";

                coord.X = 6;
                coord.Y = 19;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 246);
                cout << bank_accounts[li].card1_number;

                coord.X = 44;
                coord.Y = 19;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 246);
                cout << "0.00 $";

                coord.X = 6;
                coord.Y = 21;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 246);
                cout << "Virtual MC Card";

                coord.X = 43;
                coord.Y = 21;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 246);
                cout << "Available";

                coord.X = 6;
                coord.Y = 22;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 246);
                cout << bank_accounts[li].card2_number;

                coord.X = 44;
                coord.Y = 22;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 246);
                cout << "0.00 $";

                SetConsoleTextAttribute(hConsole, 111);
                for (int i = 26; i < 34; i++) {
                    for (int j = 4; j < 57; j++) {
                        coord.X = j;
                        coord.Y = i;
                        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                        cout << " ";
                    }
                }

                coord.X = 6;
                coord.Y = 27;
                SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                SetConsoleTextAttribute(hConsole, 111);
                cout << "Money Boxes";
                bool box_found = false;
                int l = -1;
                for (int i = 0; i < moneyboxes.size(); i++) {
                    if (moneyboxes[i].email == bank_accounts[li].email) {
                        box_found = true;
                        l = i;
                        break;
                    }
                }

                if (box_found == false) {
                    coord.X = 6;
                    coord.Y = 29;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << "Do you want to set a savings goal and save money";
                    coord.X = 6;
                    coord.Y = 30;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << "easily?";

                    coord.X = 6;
                    coord.Y = 32;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << "Open a Money Box now!";
                }
                else {
                    coord.X = 23;
                    coord.Y = 27;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << moneyboxes[l].box_name << " - " << moneyboxes[l].category;

                    coord.X = 17;
                    coord.Y = 29;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << "Goal";

                    coord.X = 37;
                    coord.Y = 29;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << "Saved";

                    coord.X = 17;
                    coord.Y = 30;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    intPart;
                    fractionalPart = modf(moneyboxes[l].goal, &intPart);

                    if (fractionalPart == 0.0) {
                        cout << moneyboxes[l].goal << ".00 $";
                    }
                    else {
                        cout << moneyboxes[l].goal << " $";
                    }


                    coord.X = 37;
                    coord.Y = 30;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    intPart;
                    fractionalPart = modf(moneyboxes[l].saved, &intPart);

                    if (fractionalPart == 0.0) {
                        cout << moneyboxes[l].saved << ".00 $";
                    }
                    else {
                        cout << moneyboxes[l].saved << " $";
                    }

                    coord.X = 6;
                    coord.Y = 32;
                    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
                    cout << "Expires at : " << moneyboxes[l].end_date[0] << moneyboxes[l].end_date[1] << "/" << moneyboxes[l].end_date[2] << moneyboxes[l].end_date[3] << "/" << moneyboxes[l].end_date[4] << moneyboxes[l].end_date[5] << moneyboxes[l].end_date[6] << moneyboxes[l].end_date[7];
                }
            }
            }
        }while (m != 'o');
    }

    
}
void show_statistics(vector<bank_account> &bank_accounts,int li,vector<moneybox> &moneyboxes,char &move) {
    std::transform(bank_accounts[li].first_name.begin(), bank_accounts[li].first_name.end(), bank_accounts[li].first_name.begin(), [](unsigned char c) {
        return std::toupper(c);
        });
    std::transform(bank_accounts[li].last_name.begin(), bank_accounts[li].last_name.end(), bank_accounts[li].last_name.begin(), [](unsigned char c) {
        return std::toupper(c);
        });

    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO consoleInfo;
    GetConsoleScreenBufferInfo(hConsole, &consoleInfo);
    WORD originalColor = consoleInfo.wAttributes;
    SetConsoleTextAttribute(hConsole, originalColor);

    HANDLE consoleHandle = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cursorInfo;
    GetConsoleCursorInfo(consoleHandle, &cursorInfo);
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(consoleHandle, &cursorInfo);
    SetConsoleTextAttribute(hConsole, 127);
    system("cls");

    COORD coord;
    SetConsoleTextAttribute(hConsole, 111);
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 60; j++) {
            coord.X = j;
            coord.Y = i;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << " ";
        }
    }

    coord.X = 3;
    coord.Y = 1;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 111);
    cout << "Statistics";

    coord.X = 2;
    coord.Y = 3;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << " Insights ";

    coord.X = 16;
    coord.Y = 3;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 104);
    cout << "Transactions";

    coord.X = 33;
    coord.Y = 3;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 104);
    cout << "Budgets";

    coord.X = 45;
    coord.Y = 3;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 104);
    cout << "Reports";



    SetConsoleTextAttribute(hConsole, 246);
    for (int i = 6; i < 13; i++) {
        for (int j = 4; j < 57; j++) {
            coord.X = j;
            coord.Y = i;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << " ";
        }
    }

    coord.X = 6;
    coord.Y = 7;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << "Accounts";


    coord.X = 6;
    coord.Y = 9;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << bank_accounts[li].full_iban;

    coord.X = 43;
    coord.Y = 9;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << "Available";

    coord.X = 6;
    coord.Y = 11;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << bank_accounts[li].short_iban;

    coord.X = 44;
    coord.Y = 11;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    double intPart;
    double fractionalPart = modf(bank_accounts[li].balance, &intPart);

    if (fractionalPart == 0.0) {
        cout << bank_accounts[li].balance << ".00 $";
    }
    else {
        cout << bank_accounts[li].balance << " $";
    }



    SetConsoleTextAttribute(hConsole, 246);
    for (int i = 15; i < 24; i++) {
        for (int j = 4; j < 57; j++) {
            coord.X = j;
            coord.Y = i;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << " ";
        }
    }

    coord.X = 6;
    coord.Y = 16;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << "Cards";


    coord.X = 6;
    coord.Y = 18;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << "Debit Mastercard";

    coord.X = 43;
    coord.Y = 18;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << "Available";

    coord.X = 6;
    coord.Y = 19;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << bank_accounts[li].card1_number;

    coord.X = 44;
    coord.Y = 19;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << "0.00 $";

    coord.X = 6;
    coord.Y = 21;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << "Virtual MC Card";

    coord.X = 43;
    coord.Y = 21;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << "Available";

    coord.X = 6;
    coord.Y = 22;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << bank_accounts[li].card2_number;

    coord.X = 44;
    coord.Y = 22;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << "0.00 $";


    SetConsoleTextAttribute(hConsole, 246);
    for (int i = 26; i < 34; i++) {
        for (int j = 4; j < 57; j++) {
            coord.X = j;
            coord.Y = i;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << " ";
        }
    }

    coord.X = 6;
    coord.Y = 27;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 246);
    cout << "Money Boxes";
    bool box_found = false;
    int l = -1;
    for (int i = 0; i < moneyboxes.size(); i++) {
        if (moneyboxes[i].email == bank_accounts[li].email) {
            box_found = true;
            l = i;
            break;
        }
    }

    if (box_found == false) {
        coord.X = 6;
        coord.Y = 29;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        cout << "Do you want to set a savings goal and save money";
        coord.X = 6;
        coord.Y = 30;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        cout << "easily?";

        coord.X = 6;
        coord.Y = 32;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        cout << "Open a Money Box now!";
    }
    else {
        coord.X = 23;
        coord.Y = 27;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        cout << moneyboxes[l].box_name << " - " << moneyboxes[l].category;

        coord.X = 17;
        coord.Y = 29;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        cout << "Goal";

        coord.X = 37;
        coord.Y = 29;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        cout << "Saved";

        coord.X = 17;
        coord.Y = 30;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        intPart;
        fractionalPart = modf(moneyboxes[l].goal, &intPart);

        if (fractionalPart == 0.0) {
            cout << moneyboxes[l].goal << ".00 $";
        }
        else {
            cout << moneyboxes[l].goal << " $";
        }


        coord.X = 37;
        coord.Y = 30;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        intPart;
        fractionalPart = modf(moneyboxes[l].saved, &intPart);

        if (fractionalPart == 0.0) {
            cout << moneyboxes[l].saved << ".00 $";
        }
        else {
            cout << moneyboxes[l].saved << " $";
        }

        coord.X = 6;
        coord.Y = 32;
        SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
        cout << "Expires at : " << moneyboxes[l].end_date[0] << moneyboxes[l].end_date[1] << "/" << moneyboxes[l].end_date[2] << moneyboxes[l].end_date[3] << "/" << moneyboxes[l].end_date[4] << moneyboxes[l].end_date[5] << moneyboxes[l].end_date[6] << moneyboxes[l].end_date[7];
    }
    SetConsoleTextAttribute(hConsole, 111);
    for (int i = 37; i < 40; i++) {
        for (int j = 0; j < 60; j++) {
            coord.X = j;
            coord.Y = i;
            SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
            cout << " ";
        }
    }
    coord.X = 4;
    coord.Y = 38;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 104);
    cout << "Home";

    

    coord.X = 12;
    coord.Y = 38;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 111);
    cout << "Statistics";

    coord.X = 11;
    coord.Y = 37;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 111);
    cout << "____________";

    coord.X = 26;
    coord.Y = 38;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 104);
    cout << "Transfers";

    coord.X = 39;
    coord.Y = 38;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 104);
    cout << "Payments";

    coord.X = 51;
    coord.Y = 38;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), coord);
    SetConsoleTextAttribute(hConsole, 104);
    cout << "Profile";
}
void show_transfers() {

}
void show_payments() {

}
void show_profile() {

}
int main() {
   
    int console_width = 60;   
    int console_height = 40;

    HANDLE console = GetStdHandle(STD_OUTPUT_HANDLE);
    SMALL_RECT rect;
    COORD coord;

    rect.Left = 0;
    rect.Top = 0;
    rect.Right = console_width - 1;
    rect.Bottom = console_height - 1;

    SetConsoleWindowInfo(console, TRUE, &rect);

    coord.X = console_width;
    coord.Y = console_height;
    SetConsoleScreenBufferSize(console, coord);
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);

    SetConsoleTextAttribute(hConsole,111 );

    get_login_button();
    get_signup_button();
    get_form();
    system("cls");
    open_loading();
    bool foun=false,yes=false;
    int li;
    vector<bank_account> bank_accounts;  
    vector<moneybox> moneyboxes;
    load_accounts(bank_accounts);
    load_moneyboxes(moneyboxes);

    for (int i = 0; i < bank_accounts.size(); i++) {
        if (bank_accounts[i].remember) {
            foun = true;
            li = i;
            break;
        }
    }
    char move='s';
    bool log;
    log = login_singup();
    switch (log) {
    case true:if (foun == true) {
                    open_loading();
                    show_home(bank_accounts, li, moneyboxes,move);
              }
              else {
                    login(bank_accounts, li,yes);
                    if (yes == true) {
                        bank_accounts[li].remember = true;
                        for (int i = 0; i < bank_accounts.size(); i++) {
                            if (i != li) {
                                bank_accounts[i].remember = false;
                            }
                        }
                        save_accounts(bank_accounts);
                    }
                    else {
                        bank_accounts[li].remember = false;
                        save_accounts(bank_accounts);
                    }
                    
                    open_loading();
                    show_home(bank_accounts, li, moneyboxes, move);
              }
              
              break;
    case false:signup(bank_accounts);
               login(bank_accounts, li, yes);
               if (yes == true) {
                   bank_accounts[li].remember = true;
                   save_accounts(bank_accounts);
                   for (int i = 0; i < bank_accounts.size(); i++) {
                       if (i != li) {
                           bank_accounts[i].remember = false;
                       }
                   }
               }
               else {
                   bank_accounts[li].remember = false;
                   save_accounts(bank_accounts);
               }
               
               open_loading();
               show_home(bank_accounts, li, moneyboxes, move);
               break;
    }
    
    bool home = true, stats = false, transfers = false, payments = false, profile = false;
    do {

        move = _getch();
        switch (move) {
        case KEY_RIGHT:if (home == true) {
                            home = false;
                            stats = true;
                            show_statistics(bank_accounts,li,moneyboxes, move);
                       }
                      else if (stats == true) {
                            show_transfers();
                        }
                      else if (transfers == true) {
                            show_payments();

                        }
                      else if (payments == true) {
                            show_profile();
                        }
                      break;
        case KEY_LEFT:if (stats == true) {
                            stats = false;
                            home = true;
                            show_home(bank_accounts,li,moneyboxes, move);
                      }
                      else if (transfers == true) {
                            show_statistics(bank_accounts, li, moneyboxes, move);
                      }
                      else if (payments == true) {
                            show_transfers();

                      }
                      else if (profile == true) {
                            show_payments();
                      }
                        break;
        case KEY_UP:if (home == true) {
            show_home(bank_accounts, li, moneyboxes,move);
                    }
        }

    } while (move != 'o');
    return 0;

}