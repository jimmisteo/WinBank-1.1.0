#include "bank_account.h"
#include <ctime>;
#include <vector>

bank_account::bank_account() {
	first_name = "NONE";
	last_name = "NONE";
	email = "NONE";
	password = "NONE";
	id_number = "NONE";
	afm = "NONE";
	birth_date = "00/00/0000";
	income = 0;
	remember = false;
	int k[16];
	srand(time(NULL));
	for (int i = 0; i < 11; i++) {
		k[i] = rand() % 9;
	}
	full_iban = "GR"+ std::to_string(k[0]) + std::to_string(k[1]) + std::to_string(k[2]) + std::to_string(k[3]) + std::to_string(k[4]) + "4290000042900" + std::to_string(k[5]) + std::to_string(k[6]) + std::to_string(k[7]) + std::to_string(k[8]) + std::to_string(k[9]) + std::to_string(k[10]) ;
	short_iban = "42900" + std::to_string(k[5]) + std::to_string(k[6]) + std::to_string(k[7]) + std::to_string(k[8]) + std::to_string(k[9]) + std::to_string(k[10]);
	balance = 0.0f;
	for (int i = 0; i < 16; i++) {
		k[i] = rand() % 9;
	}
	card1_number= std::to_string(k[0]) + std::to_string(k[1]) + std::to_string(k[2]) + std::to_string(k[3]) + " " + std::to_string(k[4]) + std::to_string(k[5]) + std::to_string(k[6]) + std::to_string(k[7]) + " " + std::to_string(k[8]) + std::to_string(k[9]) + std::to_string(k[10]) + std::to_string(k[11]) + " " +  std::to_string(k[12]) + std::to_string(k[13]) + std::to_string(k[14]) + std::to_string(k[15]);

	for (int i = 0; i < 16; i++) {
		k[i] = rand() % 9;
	}
	card2_number = std::to_string(k[0]) + std::to_string(k[1]) + std::to_string(k[2]) + std::to_string(k[3]) + " " + std::to_string(k[4]) + std::to_string(k[5]) + std::to_string(k[6]) + std::to_string(k[7]) + " " + std::to_string(k[8]) + std::to_string(k[9]) + std::to_string(k[10]) + std::to_string(k[11]) + " " + std::to_string(k[12]) + std::to_string(k[13]) + std::to_string(k[14]) + std::to_string(k[15]);
}
